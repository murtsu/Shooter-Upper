---
name: Bug report
about: Something broke or feels wrong
labels: bug
---

**What happened**

**What you expected**

**Steps to reproduce**

**Your setup**
- Distro and version:
- Controller (or keyboard):
- Output of `shooter-upper --version`:
- Contents of `~/.config/shooter-upper/log.txt` (last lines):
